const Customize = ({ children }) => {
  return (
    <div className="preview-options">
      <h2 className="demo-title-extra">Customize</h2>

      {children}
    </div>
  );
}

export default Customize;