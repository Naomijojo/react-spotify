<div align="center">
Welcome to React Bits, the go-to open source library for high quality animated React components!
</div>

<div align="center">
    <br>
    <br>
    <img src="https://github.com/user-attachments/assets/261b7dc4-de74-425f-b15a-1a7b30b1637d" alt="react-bits logo" height="200">
    <br>
    <br>
</div>
